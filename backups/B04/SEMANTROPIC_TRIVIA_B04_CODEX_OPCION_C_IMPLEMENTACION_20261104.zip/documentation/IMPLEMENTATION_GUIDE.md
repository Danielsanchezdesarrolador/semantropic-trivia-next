# SEMANTROPIC TRIVIA — B04-C2 Opción C: guía técnica

## Identidad, autorización y alcance
El Director aprobó Opción C (Portal + Personajes) y nuevos diseños oficiales de protagonista masculino/femenino/robot. Este paquete entrega recursos reutilizables para la **pantalla `/#lobby-transition`**, no una autorización de modificar otras pantallas ni `main`. No alterar D-049 `/#welcome`, DA-B04-A2, lógica de autenticación, Arena, lobby o Q03/Q04.

## Estado del material
- Tres PNG nativos con canal alfa real (resolución nativa 1122x1402 y 1254x1254) + remuestreos hasta 2048 px, que NO crean detalle nativo adicional.
- WEBP optimizados para uso web. Solo copiar los assets web necesarios a `public/assets/access/b04-option-c/` o ruta equivalente ya vigente, usando nombres coherentes. No subir el ZIP ni láminas en `public`.
- Fondos limpios de personajes, textos, logotipo y botones, en 16:9 y 9:16; **ambos fondos contienen ilustrado el portal original del escenario**. Existe además `portal-standalone-v1.*` para variantes futuras: **no superponer otro portal sobre un fondo que ya lo contiene**.
- Elementos ornamentales PNG/WebP con alfa recortados del spritesheet transparente. No reconstruirlo como si los fondos con portal fueran sin portal.
- Logo de referencia visual suministrado por el Director. Su SHA-256 difiere del logo canónico de `staging` según la revisión: **la única fuente de producción autorizada sigue siendo** `public/assets/home/brand/semantropic-trivia-logo-v1.png`. No usar el logo de conceptos generados con `1.0` añadido; no sobrescribir el oficial. Si se trabaja una variante UI-v2, derivar matemáticamente del PNG real del repo y tratarla como candidato separado para QA visual.
- Composiciones `visual_reference_only` **contienen textos y botones impresos exclusivamente para comparación**; no servirlas en el runtime ni tomar la pantalla entera como fondo de React.

## Composición web (responsive real)
Crear un componente encapsulado `LobbyTransitionOptionC` y estilos propios, invocado exclusivamente en la ruta de acceso actual `lobby-transition` dentro de `src/ui/access/AccessPortal.tsx` (auditar su estructura actual antes de editar).

Capas sugeridas: 1) fondo `<picture>` desktop/mobile con `object-fit: cover` o regla por `aspect-ratio` consistente; 2) personaje masculino `<img>` izquierdo, femenino derecho, robot centrado y algo por delante, cuidando stacking y safe-area; 3) logo PNG oficial, una sola vez en la parte superior; 4) contenido semántico React (h1 + p); 5) único botón real/enlace de navegación a `#home`.

Escritorio ≥ 1024 px: escena 16:9 llena viewport, texto y CTA en franja inferior, protagonistas laterales sin invadir CTA, robot al centro delante del portal. Móvil 9:16: fondo vertical específico, personajes escalados y redistribuidos en conjunto, todos distinguibles, zona inferior reservada para texto y CTA; scroll vertical o ajuste responsivo si pantalla pequeña, sin cortar contenido crítico. Tablet/landscape: diseño intermedio. No superponer logo con barra del navegador/safe area.

Textos exactos: `¡Bienvenido/a!` / `Preparando tu entrada al lobby` / `ABRIR LOBBY LOCAL`. El CTA en `/#lobby-transition` DEBE seguir abriendo el lobby real `/#home`, sin autenticar, sin inventar sesión ni crear backend. En móvil todo el CTA táctil es real, foco visible, teclado Enter/Espacio, `prefers-reduced-motion` y sin overflow horizontal.

## Control de calidad
1) SHA-256 e imágenes abren, RGBA con alfa realmente transparente y no falsos tableros de ajedrez; 2) assets maestro vs comp/preview coinciden; 3) logo visual idéntico al canónico del repo, sin segunda marca; 4) capturas Chromium en 320x740, 390x844, 844x390, 1366x900 y 1920x1080; 5) `#welcome`, `#sign-in`, `#register`, recuperación, `#home`, `#arena`, audio y navegación siguen funcionando; 6) TypeScript, npm test, npm run build, guards, GitHub Actions verdes; 7) solo PR/merge a staging, producción `main` intacta; 8) Render DEV entrega URL verificada; 9) pruebas reales en Android corresponden al Director, no al emulador.

## Advertencias artísticas
Las ilustraciones de personajes son nuevas ilustraciones independientes conformes a rasgos aprobados, pero no una extracción píxel a píxel de la composición original; el Director debe evaluar la fidelidad de su montaje real. Las fuentes son imágenes raster y no hay proyectos PSD/AI originales recuperables.
