# SEMANTROPIC TRIVIA 1.0 — BIBLIA DE PERSONAJES OFICIALES B04

**Decisión del Director (04/11/2026):** Opción C — Portal + Personajes. Estos tres nuevos diseños son los oficiales del nuevo juego; no trasladar los personajes anteriores de Unity ni los recortes candidatos de B02.

**Maestros de identidad:** `assets/characters/*-master-native.png` (bytes originales entregados, fondo transparente), SHA-256 en `ASSET_MANIFEST.json`. No regenerar versiones a ojo ni aceptar reinterpretaciones que cambien el rostro. Las variantes UI son remuestreos y tienen menos detalle real que ilustraciones creadas nativamente en 2048 px.

## protagonist-male-v1
Cabello castaño oscuro con picos y mechones; gafas redondas azul-cian con anillos dorados encima de la cabeza; ojos castaños cálidos; chaqueta azul con capucha, bordes dorados y puños blancos; camiseta celeste con cristal azul luminoso en el pecho; pantalón azul marino con bolsillos; botas blancas/azules/doradas; guantes morados sin dedos; expresión alegre y mano extendida hacia el jugador. No cambiar peinado, gafas, color de ojos o ropa al crear nuevas poses.

## protagonist-female-v1
Cabello largo fucsia de coleta alta, ojos verdes, diadema/ornamento cian y violeta, pendiente de estrella dorada; chaqueta y falda-short violeta con zonas blancas, ribetes dorados, cristal de cinturón azul; guantes morados, botas deportivas altas blancas, violetas y doradas; brazos abiertos y sonrisa cálida. No cambiar la coleta, ojos, pendiente, paleta ni accesorios.

## mascot-robot-v1
Cabeza redondeada blanca con visera facial oscura azul marino; ojos y sonrisa LED cian; dos antenas/cristales puntiagudos dorados; auriculares laterales dorados y azul eléctrico; cuerpo blanco redondeado y cristal central cian; brazos blancos y guantes azules, sin piernas: flotación mediante propulsor con anillos cian. No convertirlo en zorro ni en un modelo robótico distinto.

**Limitación fiel al material:** los masters son PNG generados individualmente a partir del concepto aprobado; la semejanza con la lámina fue revisada visualmente, no es un calco geométricamente idéntico. Si el Director observa un rasgo distinto, corregir la fuente MAESTRA antes de producir poses. No son archivos vectoriales editables.
