# SEMANTROPIC TRIVIA 1.0 — Paquete de transferencia B04-C2 Opción C

**Fecha:** 04/11/2026 · **Destino:** Codex / solo Render DEV y GitHub `staging`.

Este archivo ZIP CONTIENE ARTWORK REAL: tres personajes PNG originales con canal alfa; sus derivados UI PNG/WebP; fondos desktop/móvil sin personajes, textos, logo ni CTA; portal separado (alternativo), cinco ornamentos separados, logo-referencia y dos montajes GUIA derivados de los assets. Incluye SHA-256, manifest y guía Codex.

**CRÍTICO:** las composiciones PNG son referencias de maquetación y contienen UI de muestra rasterizada: no utilizarlas como backgrounds de la app. En el juego todo texto/botón es React y sus imágenes separadas. El fondo escena incluye el portal: no superponer el portal standalone encima por defecto. El logo de runtime sigue siendo el original en GitHub.

**NO incluidos:** PSD/AI 100% editables, PNG nativos de personaje >=2048, extracción perfecta de la ilustración compuesta, compromiso de identidad 100% píxel a píxel con el board. Los derivados de 2048 son escalados para interfaz y se señalan como tales.

**Alcance autorizado:** actualizar SOLO `#lobby-transition`, previa validación de CI, en el mismo Render DEV fijo. `main`, D-049, lobby y Arena se preservan.

Orden de lectura: `documentation/CHARACTER_BIBLE.md`, `documentation/IMPLEMENTATION_GUIDE.md`, `documentation/PROMPT_CODEX_B04_C2.txt`, `documentation/ASSET_MANIFEST.json`, `documentation/SHA256SUMS.txt`, `references/OPCION_C_TABLERO_APROBADO.png`.
